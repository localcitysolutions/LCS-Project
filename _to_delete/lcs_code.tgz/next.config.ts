import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin("./src/i18n/request.ts");

const securityHeaders = [
  {
    key: "X-Content-Type-Options",
    value: "nosniff",
  },
  {
    key: "X-Frame-Options",
    value: "SAMEORIGIN",
  },
  {
    key: "X-DNS-Prefetch-Control",
    value: "on",
  },
  {
    key: "Referrer-Policy",
    value: "strict-origin-when-cross-origin",
  },
  {
    key: "Content-Security-Policy",
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com https://www.google-analytics.com https://googleads.g.doubleclick.net https://www.googleadservices.com https://connect.facebook.net https://www.clarity.ms",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: blob: https://images.unsplash.com https://www.google-analytics.com https://www.googletagmanager.com https://localcitysolutions.com https://cms.localcitysolutions.com",
      "connect-src 'self' https://www.google-analytics.com https://analytics.google.com https://api.web3forms.com https://pagespeedonline.googleapis.com https://www.clarity.ms https://cms.localcitysolutions.com https://*.supabase.co",
      "frame-src 'self' https://www.google.com https://maps.google.com https://www.googletagmanager.com",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self' https://api.web3forms.com",
    ].join("; "),
  },
];

const nextConfig: NextConfig = {
  images: {
    // AVIF first — typically 30-50% smaller than WebP for photos; browsers
    // that don't accept AVIF (older Safari etc.) fall back to WebP
    // automatically via the next/image content negotiation.
    formats: ["image/avif", "image/webp"],
    // Keep the normal 75 quality default, plus 85 for above-the-fold hero
    // images where the source photo needs a little extra crispness.
    qualities: [75, 85],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 60 * 60 * 24 * 30, // 30 days
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: securityHeaders,
      },
    ];
  },
  async redirects() {
    return [
      // 301s: old WordPress blog slugs → new Next.js blog posts
      // Runs at the edge before locale middleware — safe for non-prefixed legacy paths
      {
        source: "/facebook-marketing-cost-in-saudi-arabia-2025",
        destination: "/en/blog/facebook-marketing-cost-saudi-arabia-2026",
        permanent: true,
      },
      {
        source: "/social-media-marketing-cost-in-saudi-arabia",
        destination: "/en/blog/social-media-marketing-cost-saudi-arabia",
        permanent: true,
      },
      {
        source: "/instagram-marketing-cost-in-saudi-arabia",
        destination: "/en/blog/instagram-marketing-cost-saudi-arabia",
        permanent: true,
      },
    ];
  },
};

export default withNextIntl(nextConfig);
